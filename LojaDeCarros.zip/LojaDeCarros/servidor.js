const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require("mongodb").MongoClient;

const app = express();

const uri = 'mongodb+srv://rafaelboquira098:20122960@cluster0.g8oxncb.mongodb.net/?retryWrites=true&w=majority'
const client = new MongoClient(uri, { useNewUrlParser: true });

app.use(express.static('./public'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.set('view engine' , 'ejs');
app.set('views', './views');

const server = http.createServer(app);

server.listen(80);

console.log("Servidor rodando...");

app.get("/cadastrar_usuario", function(req,resp){
    resp.redirect('cadastro.html')
});

app.post('/cadastrar_usuario', function(req,resp){
    
    client.db('Carros').collection('usuarios').insertOne(
        {db_nome: req.body.nome , db_login: req.body.login, db_senha: req.body.senha}, function(err){
        
        if (err) {
            resp.render('resposta_cadastro' , {resposta: "Erro ao cadastrar!"})
        } else {
            resp.render('resposta_cadastro' , {resposta: 'Usuario criado com sucesso!'})
        }
    });
});

app.get('/login_usuario', function(req,resp){
    resp.redirect('login.html')
});

app.post('/login_usuario', function(req,resp){

    client.connect((err) => {
        client.db('Carros').collection('usuarios').find(
        {db_login: req.body.login, db_senha: req.body.senha}).toArray(function(err,items){
            console.log(items);
            if (items.length == 0){
                resp.render('resposta_login' ,{resposta: 'Usuario ou senha não encontrado'})
            } else if(err){
                resp.render('resposta_login',{resposta: 'Erro ao logar'})
            } else{
                resp.render('resposta_login1',{resposta: 'Login realizado com sucesso!'})
            }
        })
    })
})

app.get("/listar_carros", function(req, resp) {

    client.connect((err) => {
      client
        .db("Carros")
        .collection("meuCarros")
        .find().toArray(function(err, items) {
          
          resp.render("listar_carros", { meuCarros: items });
        });
    });  
  
});

app.get('/gerenciamento_carros', function(req,resp){
    resp.redirect('gerenciamento_carros.html')
})

app.get('/cadastrar_carro', function(req,resp){
    resp.redirect('cadastrar_carro.html')
});

app.post('/cadastrar_carro', function(req,resp){
    
    client.db('Carros').collection('meuCarros').insertOne(
        {db_nome: req.body.nome , db_marca: req.body.marca, db_ano: req.body.ano, db_quantidade: req.body.quantidade}, function(err){
        
        if (err) {
            resp.render('resposta' , {resposta: "Erro ao cadastrar!"})
        } else {
            resp.render('resposta' , {resposta: 'Carro cadastrado com sucesso!'})
        }
    });
});

app.get('/remover_carro', function(req,resp){
    resp.redirect('/remover_carro.html')
});

app.post('/remover_carro', function(req,resp){

    client.connect((err) => {
        client.db('Carros').collection('meuCarros').deleteOne(
            {db_nome: req.body.nome, db_marca: req.body.marca , db_ano: req.body.ano},function(err, result){
                console.log(result)
                
                if (result.deletedCount == 0){
                    resp.render('resposta' ,{resposta: 'Carro não encontrado'})
                } else if(err){
                    resp.render('resposta',{resposta: 'Erro ao remover o carro'})
                } else{
                    resp.render('resposta', {resposta: 'Removido com sucesso!'})
                }
        })
    })
});


app.get('/atualizar_carro', function(req,resp){
    resp.redirect('/atualizar_carro.html')
});

app.post('/atualizar_carro', function(req,resp){
    client.connect((err) => {
        client.db('Carros').collection('meuCarros').updateOne(
            {db_nome: req.body.nome, db_marca: req.body.marca, db_ano: req.body.ano, db_valor: req.body.valor, db_quantidade: req.body.quantidade} , 
            { $set: {db_novaquantidade: req.body.novaquantidade}} , function(err, result){
                console.log(result)

                if (result.modifiedCount == 0) {
                    resp.render('resposta', {resposta: 'Carro não encontrado'})
                } else if (err){
                    resp.render('resposta' , {resposta: 'Erro ao atualizar a quantidade'})
                } else {
                    resp.render('resposta' , {resposta: 'Quanridade atualizada com sucesso!'})
                }
            }
        )
    })
});